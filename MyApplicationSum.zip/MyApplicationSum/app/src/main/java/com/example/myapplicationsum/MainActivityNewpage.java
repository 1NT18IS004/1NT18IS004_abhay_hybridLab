package com.example.myapplicationsum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivityNewpage extends AppCompatActivity {
    String TAG = "MainActivityNewpage";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main_newpage);

        TextView num = (TextView) findViewById(R.id.textView);
        Intent intent = getIntent();
        //Log.d(TAG, "Activity2 onCreate: " + bundle.getString("key1"));
        String res = intent.getStringExtra("ans");
        Log.d(TAG, "onCreate: " + res);
        num.setText("Result is : "+res);



}
}