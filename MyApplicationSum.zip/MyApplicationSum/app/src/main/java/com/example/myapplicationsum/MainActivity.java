package com.example.myapplicationsum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "Activity1 onCreate: ");
    Intent it =new Intent(this,MainActivityNewpage.class);



        Button bt;
        bt = findViewById(R.id.bt);


            EditText n1 = findViewById(R.id.one);

            EditText n2 = findViewById(R.id.two);

            TextView res = findViewById(R.id.sum);
        bt.setOnClickListener((new View.OnClickListener() {
            @Override
            public  void onClick(View view){
                double num1 = Double.parseDouble(n1.getText().toString());
                double num2 = Double.parseDouble(n2.getText().toString());
                double result =num1+num2;

                res.setText(Double.toString(result));
                String str = Double.toString(result);
                it.putExtra("ans", str);
                startActivity(it);


            }
    }));
}
}