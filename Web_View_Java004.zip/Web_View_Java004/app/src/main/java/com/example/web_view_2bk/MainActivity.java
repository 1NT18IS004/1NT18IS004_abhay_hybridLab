package com.example.web_view_2bk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    WebView myWebView = new WebView(this);
    setContentView(myWebView);
    myWebView.loadUrl("https://google.com/");
    }
}